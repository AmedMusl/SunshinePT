# Poptracker layout for Sunshine

This is a map tracker which includes all shine and blue coin locations for poptracker

## Installation

Just download the latest release and put it in the packs folder

## More Info

Check out the Sunshine Thread in AP server for more info

## Future Plans

- Figure out how to make Boathouse trades visible based on the maximum for Boathouse Trades
- Find out how to autotrack tickets if level order is vanilla (if this is even possible?)
- Maybe Auto Switching Maps based on what level you are

## Credits

- Schwarts Gandhi: Major Contributor for his work on the layout and most of the logic

- JXJacob: Helped get me setup with finding item and location mapping plus helping me a lot with figuring out how autotracking works

- VGCartographer: DeviantArtist who provided all the maps to make this possible

None of this wouldve been possible without them and Huge Thanks to the APworld devs who made Sunshine AP possible <3
